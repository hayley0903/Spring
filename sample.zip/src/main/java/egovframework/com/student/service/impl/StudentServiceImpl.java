package egovframework.com.student.service.impl;

import org.springframework.stereotype.Service;

import egovframework.com.student.service.StudentService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("StudentService")
public class StudentServiceImpl  extends EgovAbstractServiceImpl implements StudentService{

}
