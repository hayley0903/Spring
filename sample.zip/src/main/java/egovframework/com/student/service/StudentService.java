package egovframework.com.student.service;

public interface StudentService {

}
