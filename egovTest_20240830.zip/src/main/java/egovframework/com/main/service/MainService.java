package egovframework.com.main.service;

import java.util.HashMap;

public interface MainService {
   
   public int selectIdChk(HashMap<String, Object> paramMap);

   public int insertMember(HashMap<String, Object> paramMap);
}
